import  { useState } from 'react';
import axios from 'axios';
const SearchRecipes = () => {
  const [query, setQuery] = useState('');
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const handleSearch = async () => {
    if (!query) return; 
    setLoading(true);
    setError('');
    try {
      const response = await axios.get(`https://www.themealdb.com/api/json/v1/1/search.php?s=${query}`);
      setRecipes(response.data.meals || []); 
    } catch (err) {
      console.error(err);
      setError('Failed to fetch recipes');
    }
    setLoading(false);
  };
  return (
    <div>
      <h2>Search Recipes</h2>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search for recipes"
      />
      <button onClick={handleSearch}>Search</button>

      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}
      <div>
        {recipes.length > 0 ? (
          recipes.map((recipe) => (
            <div key={recipe.idMeal} style={{ margin: '20px 0' }}>
              <h3>{recipe.strMeal}</h3>
              <img src={recipe.strMealThumb} alt={recipe.strMeal} style={{ width: '200px' }} />
            </div>
          ))
        ) : (
          <p>No recipes found.</p>
        )}
      </div>
    </div>
  );
};
export default SearchRecipes;
