import "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Recipe Finder App</h1>
      <p>Use the navigation links above to explore the app.</p>
    </div>
  );
};
export default Home;
