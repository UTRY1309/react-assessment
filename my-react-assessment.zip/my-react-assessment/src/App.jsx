import "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./component/home";
import SearchRecipes from "./component/search-recipes";
import ViewRecipes from "./component/view-recipes";
import AddRecipe from "./component/add-recipes";
import "./App.css"; 

const App = () => {
  return (
    <div className="app-container">
      <Router>
        <nav className="navigation">
          <Link to="/">Home</Link>
          <Link to="/search-recipes">Search Recipes</Link>
          <Link to="/view-recipes">View Recipes</Link>
          <Link to="/add-recipe">Add Recipe</Link>
        </nav>
        <div className="content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/search-recipes" element={<SearchRecipes />} />
            <Route path="/view-recipes" element={<ViewRecipes />} />
            <Route path="/add-recipe" element={<AddRecipe />} />
          </Routes>
        </div>
      </Router>
    </div>
  );
};

export default App;
