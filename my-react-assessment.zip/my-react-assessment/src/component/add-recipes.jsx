import  "react";
const AddRecipe = () => {
  return (
    <div className="add-recipe-container">
      <h2>Add Recipe</h2>
      <form className="add-recipe-form">
        <div>
          <label>Recipe Name:</label>
          <input type="text" name="recipeName" placeholder="Enter recipe name" />
        </div>
        <div>
          <label>Category:</label>
          <select name="category">
            <option value="">Select Category</option>
            <option value="breakfast">Breakfast</option>
            <option value="lunch">Lunch</option>
            <option value="dinner">Dinner</option>
            <option value="dessert">Dessert</option>
          </select>
        </div>
        <div>
          <label>Ingredients (comma-separated):</label>
          <input
            type="text"
            name="ingredients"
            placeholder="Enter ingredients"
          />
        </div>
        <button type="submit">Add Recipe</button>
      </form>
    </div>
  );
};
export default AddRecipe;
