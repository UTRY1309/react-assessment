import "react";
const ViewRecipes = () => {
  return (
    <div>
      <h2>View Recipes</h2>
      <p>No recipes available yet. Start by adding a new recipe!</p>
    </div>
  );
};
export default ViewRecipes;
